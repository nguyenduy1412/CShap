﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NguyenNgocDuy
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.OutputEncoding= Encoding.UTF8;
            TH01.Cau1();
            TH01.Cau2();
            TH01.Cau3();
            TH01.Cau4();
            TH01.Cau5();
            Console.ReadLine();
            
        }
    }
}
